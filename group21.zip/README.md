# cs_project  
### Compile server.c  

`gcc cJSON.c Server/server.c -o Server/server`  


### Compile client.c  

`gcc Client/client.c -o Client/client`  